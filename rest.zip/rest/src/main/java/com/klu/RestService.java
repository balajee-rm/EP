package com.klu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Application;

@ApplicationPath("/service")
@Path("/")
public class RestService extends Application{
	@GET
	@Path("/abc/{name}")
	public String fun1(@PathParam("name") String name) {
		return "HELLO " + name;				
	}
	
	@POST
	@Path("/abc")
	public String fun2(@FormParam("name") String name) {
		return "POST HELLO " + name;				
	}
	
	@DELETE
	@Path("/abc/{id}")
	public String fun3(@PathParam("id") int id) {
		return "Deleted" + id;				
	}	
	
	@GET
	@Path("/trigger/{id}")
	public void fun4(@PathParam("id") int id) throws IOException {
		URL url = new URL("http://localhost:8080/rest/service/abc/" + id);	
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setRequestMethod("DELETE");
		con.setRequestProperty("Accept", "application/json");
		BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
		System.out.println(br.readLine());
	}

}
