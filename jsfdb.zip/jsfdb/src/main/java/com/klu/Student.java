package com.klu;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Persistence;
import javax.persistence.Table;

@Entity
@Table(name="stu_table1")
public class Student implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	int id;
	@Column(name="stu_name")
	String name;
	double cgpa;
	
	@ManyToOne
	@JoinColumn(name="teacher")
	Teacher teacher;
	
	public Teacher getTeacher() {
		return teacher;
	}
	public void setTeacher(int t_id) {
		EntityManagerFactory emf = new Persistence().createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		Teacher teacher = em.find(Teacher.class, t_id);
		em.close();
		emf.close();
		this.teacher = teacher;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCgpa() {
		return cgpa;
	}
	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}
	public String toString() {
		return "ID: " + id + ", NAME: " + name + ", CGPA: " + cgpa + ", Teacher: " + teacher;
	}
}
