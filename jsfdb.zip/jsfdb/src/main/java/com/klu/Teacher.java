package com.klu;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="teacher")
public class Teacher {
	
	@Id
	int id;
	@Column(name="t_name")
	String name;
	
	@OneToMany(mappedBy = "teacher", fetch = FetchType.EAGER)
	List<Student> students;
	
	
	public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String toString() {
		System.out.println("Teacher Object Printing");
		System.out.println(students);
		return "ID: " + id + ", NAME: " + name;
	}
	
}
