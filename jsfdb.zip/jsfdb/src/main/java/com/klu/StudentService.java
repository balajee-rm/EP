package com.klu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.Permissions;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.faces.bean.ManagedBean;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.validation.constraints.NotNull;

@ManagedBean(name="S", eager=true)
@TransactionManagement(value=TransactionManagementType.BEAN)
public class StudentService {
	
	@NotNull(message="It shoule not be null")
	int id;
	String name;
	double cgpa;
	
	int t_id;

	List<Student> l;
	String result = "";
	
	String msg;
	
	@Inject
	JMSService jms;
	
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public int getT_id() {
		return t_id;
	}
	public void setT_id(int t_id) {
		this.t_id = t_id;
	}
	public List<Student> getL() {
		return l;
	}
	public void setL(List<Student> l) {
		this.l = l;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCgpa() {
		return cgpa;
	}
	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}

	Student s1 = new Student();
	
	public void insert() {
		s1.setId(id);
		s1.setName(name);
		s1.setCgpa(cgpa);
		s1.setTeacher(t_id);
		try {
			EntityManagerFactory emf = new Persistence().createEntityManagerFactory("jpa");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(s1);
			em.getTransaction().commit();
			em.close();
			emf.close();
			System.out.println("Data Inserted");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void update() {
		s1.setId(id);
		s1.setName(name);
		s1.setCgpa(cgpa);
		try {
			EntityManagerFactory emf = new Persistence().createEntityManagerFactory("jpa");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.merge(s1);
			em.getTransaction().commit();
			em.close();
			emf.close();
			System.out.println("Data Updated");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void delete() {
		try {
			EntityManagerFactory emf = new Persistence().createEntityManagerFactory("jpa");
			EntityManager em = emf.createEntityManager();
			Student s2 = em.find(Student.class, id);
			em.getTransaction().begin();
			em.remove(s2);
			em.getTransaction().commit();
			em.close();
			emf.close();
			System.out.println("Data Deleted");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	public void findAll() {
		try {
			EntityManagerFactory emf = new Persistence().createEntityManagerFactory("jpa");
			EntityManager em = emf.createEntityManager();
			
			Query qry = em.createQuery("select S from Student S");
			l=qry.getResultList();
			
			em.close();
			emf.close();
			System.out.println("Data Reterieved");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	public void findAllTeacher() {
		try {
			EntityManagerFactory emf = new Persistence().createEntityManagerFactory("jpa");
			EntityManager em = emf.createEntityManager();
			
			Query qry = em.createQuery("select T from Teacher T");
			l=qry.getResultList();
			
			em.close();
			emf.close();
			System.out.println("Data Reterieved");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void callDelete() throws IOException {
		URL url = new URL("http://localhost:8080/jsfdb/rest/call/10");
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setRequestMethod("DELETE");
		con.setRequestProperty("Accept", "application/json");
		BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
		result = br.readLine();
	}
	
	public void sender() {
		jms.sendMsg(msg);
		System.out.println("Message Sent");
	}
	
	public void receiver() {
		result = jms.receiveMsg();
	}
	
	
}
