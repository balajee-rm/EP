package com.klu;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.MediaType;

@ApplicationPath("/rest")
@Path("/")
public class RestService extends Application {
	@GET
	@Path("/call")
	//@Produces(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	//@Produces(MediaType.APPLICATION_XML)
	public String fun1() {
		return "Hello World";
	}
	
	@GET
	@Path("/call/{a}/{b}")
	public String fun2(@PathParam("a") int a, @PathParam("b") int b) {
		return "a+b value is " + (a+b);
	}
	
	@POST
	@Path("/call")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public String fun3(@FormParam("a") int a, @FormParam("b") int b) {
		return "a+b value is " + (a+b);
	}
	
	@DELETE
	@Path("/call/{id}")
	public String fun4(@PathParam("id") int id) {
		return id + " got deleted";
	}
	
	@GET
	//http://localhost:8080/jsfdb/rest/trigger?a=10&b=30
	@Path("/trigger")
	public String fun5(@QueryParam("a") int a, @QueryParam("b") int b) {
		return "a+b value is " + (a+b);
	}
}
