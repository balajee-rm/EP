package com.klu;

import javax.annotation.Resource;
import javax.ejb.Stateful;
import javax.inject.Inject;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Queue;
import javax.jms.TextMessage;

@Stateful
public class JMSService {

	@Resource(mappedName = "java:/jms/queue/DLQ")
	Queue queue;
	
	@Inject
	JMSContext context;
	
	public void sendMsg(String msg) {
		JMSProducer producer = context.createProducer();
		TextMessage message = context.createTextMessage(msg);
		producer.send(queue, message);
	}
	
	public String receiveMsg() {
		String msg = "";
		JMSConsumer consumer = context.createConsumer(queue);
		TextMessage message = (TextMessage) consumer.receiveNoWait();
		try {
			msg = message.getBody(String.class);
		} catch (JMSException e) {
			e.printStackTrace();
		}
		return msg;
	}
	
}
